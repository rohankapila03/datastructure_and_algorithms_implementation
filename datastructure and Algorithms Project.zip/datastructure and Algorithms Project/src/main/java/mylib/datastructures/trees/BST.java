package trees;

import java.util.LinkedList;
import java.util.Queue;

import nodes.TNode;

public class BST {
    TNode root;

    public BST() {
        this.root = null;
    }

    public BST(int val) {
        TNode nodeCreate = new TNode(val, 0, null, null, null);
        this.root = nodeCreate;
    }

    public BST(TNode object) {
        this.root = object;
    }

    public void setRoot(TNode root) {
        this.root = root;
    }

    public TNode getRoot() {
        return this.root;
    }

    public void insert(int val) {
        this.root = insert(root, val);
    }

    private TNode insert(TNode root, int val) {
        if (root == null) {
            TNode new_node = new TNode(val, 0, null, null, null);
            return new_node;
        }
        if (val > root.getData()) {
            TNode rightInsert = insert(root.getRight(), val);
            root.setRight(rightInsert);
        } else if (val > root.getData()) {
            TNode leftInsert = insert(root.getLeft(), val);
            root.setLeft(leftInsert);
        }
        return root;
    }

    public void insert(TNode node) {
        this.root = insert(root, node);
    }

    private TNode insert(TNode root, TNode node) {
        if (root == null) {
            return node;
        }
        if (node.getData() > root.getData()) {
            TNode rightNodeInsert = insert(root.getRight(), node);
            root.setRight(rightNodeInsert);
        } else if (node.getData() < root.getData()) {
            TNode leftNodeInsert = insert(root.getLeft(), node);
            root.setLeft(leftNodeInsert);
        }
        return root;
    }

    public void delete(int val) {
        this.root = delete(root, val);
    }

    private TNode delete(TNode root, int value) {
        if (root == null) {
            System.out.println("no value found");
            return null;
        }
        if (value > root.getData()) {
            TNode rightDeleteIterator = delete(root.getRight(), value);
            root.setRight(rightDeleteIterator);
        } else if (value < root.getData()) {
            TNode leftDeleteIterator = delete(root.getLeft(), value);
            root.setLeft(leftDeleteIterator);
        } else {
            if (root.getRight() == null) {
                return root.getLeft();
            } else if (root.getLeft() == null) {
                return root.getRight();
            }
            int minValRight = minimumVal(root.getRight());
            root.setData(minValRight);
            root.setRight(delete(root.getRight(), root.getData()));
        }
        return this.root;

    }

    private int minimumVal(TNode root) {
        int minimumVal = root.getData();
        while (root.getLeft() != null) {
            minimumVal = root.getLeft().getData();
            root = root.getLeft();
        }
        return minimumVal;
    }

    public TNode search(int val) {
        return search(root, val);
    }

    private TNode search(TNode root, int value) {

        if (root == null) {
            return root;
        }
        if (root.getData() == value) {
            return root;
        }
        if (value < root.getData()) {
            return search(root.getLeft(), value);
        }
        return search(root.getRight(), value);
    }

    public void printInOrder() {
        printInOrder(root);
        System.out.println();
    }

    private void printInOrder(TNode root) {
        if (root != null) {
            printInOrder(root.getLeft());
            System.out.print(root.getData() + " ");
            printInOrder(root.getRight());
        }
    }

    public void printBF() {
        if (this.root == null) {
            System.out.println("Tree is Empty");
            return;
        }
        Queue<TNode> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            int nodecounter = queue.size();
            while (nodecounter > 0) {
                TNode node = queue.poll();
                System.out.print(node.getData() + " ");
                if (node.getRight() != null) {
                    queue.add(node.getRight());
                }
                if (node.getLeft() != null) {
                    queue.add(node.getLeft());
                }
                nodecounter = nodecounter - 1;

            }
            System.out.println();
        }
    }
}