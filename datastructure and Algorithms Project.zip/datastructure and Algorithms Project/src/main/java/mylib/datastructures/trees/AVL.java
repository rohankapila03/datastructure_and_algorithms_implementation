package trees;

import java.util.LinkedList;
import java.util.Queue;
import nodes.TNode;

public class AVL extends BST {
    public AVL() {
        super();
    }

    public AVL(int val) {
        super(val);
    }

    public AVL(TNode obj) {
        super(balanceTreeCreator(obj));
    }

    @Override
    public void setRoot(TNode obj) {
        super.setRoot(balanceTreeCreator(obj));
    }

    private static TNode balanceTreeCreator(TNode obj) {
        Queue<TNode> queue = new LinkedList<>();
        AVL avl = new AVL();
        queue.add(obj);

        while (!queue.isEmpty()) {
            TNode curr = queue.poll();
            avl.insert(curr.getData());
            if (curr.getRight() != null) {
                queue.add(curr.getRight());
            }

            if (curr.getLeft() != null) {
                queue.add(curr.getLeft());
            }
        }

        return avl.getRoot();
    }

    @Override
    public void insert(int val) {
        TNode inserted = insert(super.getRoot(), val);
        super.setRoot(inserted);
    }

    private TNode insert(TNode root, int val) {
        TNode NodeCreate = new TNode(val);
        return insert(root, NodeCreate);
    }

    @Override
    public void insert(TNode node) {
        TNode insertedNode = insert(super.getRoot(), node);
        super.setRoot(insertedNode);
    }

    protected TNode insert(TNode root, TNode node) {
        if (root == null) {
            return node;
        }

        if (node.getData() > root.getData()) {
            TNode insertRightNode = insert(root.getRight(), node);
            root.setRight(insertRightNode);
        } else if (node.getData() < root.getData()) {
            TNode insertLeftRoot = insert(root.getLeft(), node);
            root.setLeft(insertLeftRoot);
        } else {
            return root;
        }

        TNode leftroot = root.getLeft();
        TNode rightroot = root.getRight();

        root.setBalance(getSize(leftroot) - getSize(rightroot));

        if (root.getBalance() < -1) {
            if (node.getData() < rightroot.getData()) {
                root.setRight(RightShift(rightroot));
            }
            return LeftShift(root);
        }

        if (root.getBalance() > 1) {
            if (node.getData() > leftroot.getData()) {
                root.setLeft(LeftShift(leftroot));
            }
            return RightShift(root);
        }

        return root;
    }

    private int getSize(TNode node) {
        if (node == null) {
            return 0;
        }

        return Math.max(getSize(node.getLeft()), getSize(node.getRight())) + 1;
    }

    private TNode LeftShift(TNode leftroot) {
        TNode rightroot = leftroot.getRight();
        TNode temp = rightroot.getLeft();

        rightroot.setLeft(leftroot);
        leftroot.setRight(temp);

        int leftrootSizeLeft = getSize(leftroot.getLeft());

        int leftrootSizeRight = getSize(leftroot.getRight());

        int rightrootSizeLeft = getSize(rightroot.getLeft());

        int rightrootSizeRight = getSize(rightroot.getRight());

        leftroot.setBalance(leftrootSizeLeft - leftrootSizeRight);
        rightroot.setBalance(rightrootSizeLeft - rightrootSizeRight);

        return rightroot;
    }

    private TNode RightShift(TNode rightroot) {
        TNode leftroot = rightroot.getLeft();
        TNode temp = leftroot.getRight();

        leftroot.setRight(rightroot);
        rightroot.setLeft(temp);

        int leftrootSizeLeft = getSize(leftroot.getLeft());

        int leftrootSizeRight = getSize(leftroot.getRight());

        int rightrootSizeLeft = getSize(rightroot.getLeft());

        int rightrootSizeRight = getSize(rightroot.getRight());

        rightroot.setBalance(rightrootSizeLeft - rightrootSizeRight);
        leftroot.setBalance(leftrootSizeLeft - leftrootSizeRight);

        return leftroot;
    }
}
