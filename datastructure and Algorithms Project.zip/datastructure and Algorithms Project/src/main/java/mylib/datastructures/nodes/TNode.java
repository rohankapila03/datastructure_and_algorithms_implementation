package nodes;

public class TNode {
    int data;
    TNode left;
    TNode right;
    TNode parent;
    int balance;

    public TNode() {
        this.data = 0;
        this.left = null;
        this.right = null;
        this.parent = null;
        this.balance = 0;

    }

    public TNode(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
        this.parent = null;
        this.balance = 0;
    }

    public TNode(int data, int balance, TNode P, TNode L, TNode R) {
        this.data = data;
        this.left = L;
        this.right = R;
        this.parent = P;
        this.balance = balance;

    }

    public int getData() {
        return this.data;
    }

    public TNode getLeft() {
        return this.left;
    }

    public TNode getRight() {
        return this.right;
    }

    public TNode getParent() {
        return this.parent;
    }

    public int getBalance() {
        return this.balance;
    }

    public void setData(int data) {
        this.data = data;
    }

    public void setLeft(TNode Left) {
        this.left = Left;
    }

    public void setRight(TNode Right) {
        this.right = Right;
    }

    public void setParent(TNode Parent) {
        this.parent = Parent;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public void print() {
        System.out.println("INFORMATION ON NODE:");
        System.out.println("THE DATA IS:" + data);
        System.out.println("LEFT:" + (left != null ? left.getData() : "none"));
        System.out.println("RIGHT:" + (right != null ? right.getData() : "none"));
        System.out.println("PARENT:" + (parent != null ? parent.getData() : "none"));
        System.out.println("BALANCE" + balance);
    }

    @Override
    public String toString() {
        return Integer.toString(data);
    }

}