package linear;
import nodes.DNode;
public class StackLL extends SLL{
    
    public StackLL() {
        super();
    }

    public void push(int data) {
        DNode newNode = new DNode(data);
        super.insertHead(newNode);
    }

    public boolean isEmpty() {
        return listSize == 0;
    }

    public int listSize() {
        return listSize;
    }

    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("The Stack is empty.");
        }
        int data = head.data;
        super.deleteHead();
        return data;
    }

    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("The stack is empty.");
        }
        return head.data;
    }

    @Override
    public void insertTail(DNode node) {}

    @Override
    public void insert(DNode node, int position) {}

    @Override
    public void sortedInsert(DNode node) {}

    @Override
    public void deleteTail() {}

    @Override
    public void delete(int data) {}

    @Override
    public void sort() {}


}


