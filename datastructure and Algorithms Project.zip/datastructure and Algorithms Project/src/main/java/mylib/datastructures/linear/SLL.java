package linear;
import nodes.DNode;

public class SLL {
    protected DNode head;
    protected DNode tail;
    protected int listSize;

    public SLL() {
        head = null;
        tail = null;
        listSize = 0;
    }

    public SLL(DNode head) {
        this.head = head;
        this.tail = head;
        listSize = 1;
    }

    public void insertHead(DNode node) {
        node.next = head;
        head = node;
        if (tail == null) {
            tail = node;
        }
        listSize++;
    }

    public void insertTail(DNode node) {
        if (head == null) {
            head = node;
            tail = node;
        } 
        else {
            tail.next = node;
            tail = node;
        }
        listSize++;
    }

    public void insert(DNode node, int position) {
        if (position < 0 || position > listSize) {
            throw new IllegalArgumentException("Invalid position");
        }
       
        if (position == 0) {
            insertHead(node);
        } 
        
        else if (position == listSize) {
            insertTail(node);
        } 
       
        else {
            DNode current = head;
            for (int i = 1; i < position - 1; i++) {
                current = current.next;
            }
            
            node.next = current.next;
            current.next = node;
            listSize++;
        }
    }

    public boolean isSorted() {
        if (head == null || head.next == null) {
            return true;
        }
        
        DNode current = head; 
        while (current.next != null) {
            if (current.data > current.next.data) {
                return false;
            }
            current = current.next;
        }
        return true;
    }

    public void sort() {
        if (head == null || head.next == null) {
            return;
        }
    
        DNode sortedList = null;
        DNode current = head;
        while (current != null) {
            DNode nextNode = current.next;
            sortedList = insertIntoSortedList(sortedList, current);
            current = nextNode;
        }
        
        head = sortedList;
    }

    public void sortedInsert(DNode node) {
        if (!isSorted()) {
            sort();
        }
    
        if (head == null || head.data >= node.data) {
            insertHead(node);
        } 
        else {
            DNode current = head;
            while (current.next != null && current.next.data < node.data) {
                current = current.next;
            }
            
            node.next = current.next;
            current.next = node; 
            if (current == tail) {
                tail = node;
            }
            listSize++;
        }
    }
    
    public void deleteHead() {
        if (head != null) {
            head = head.next;
            listSize--;
            if (listSize == 0) {
                tail = null;
            }
        }
    }

    public void deleteTail() {
        if (head != null) {
            if (head == tail) {
                head = null;
                tail = null;
            } 
            
            else {
                DNode current = head;
                while (current.next != tail) {
                    current = current.next;
                }
                current.next = null;
                tail = current;
            }
            listSize--;
        }
    }

    public void delete(int data) {
        if (head == null) {
            return;
        }
        if (head.data == data) {
            deleteHead();
            return;
        }
        DNode current = head;
        while (current.next != null && current.next.data != data) {
            current = current.next;
        }
        if (current.next != null) {
            if (current.next == tail) {
                deleteTail();
            } else {
                current.next = current.next.next;
                listSize--;
            }
        }
    }

    public void clear() {
        head = null;
        tail = null;
        listSize = 0;
    }

    public DNode search(int data) {
        DNode current = head;
        while (current != null) {
            if (current.data == data) {
                return current;
            }
            
            current = current.next;
        }
        return null;
    }

    private DNode insertIntoSortedList(DNode sortedList, DNode node) {
        if (sortedList == null || sortedList.data >= node.data) {
            node.next = sortedList;
            return node;
        } else {
            DNode current = sortedList;
            while (current.next != null && current.next.data < node.data) {
                current = current.next;
            }
            node.next = current.next;
            current.next = node;
            return sortedList;
        }
    }

    public void print() {   
        System.out.println("Length: " + listSize);
        System.out.println("Sorted?: " + (isSorted() ? "Yes" : "No"));
    
        System.out.print("Contents: ");
        DNode current = head;
        while (current != null) {
            System.out.print(current.data + (current.next != null ? " -> " : ""));
            current = current.next;
        }
        System.out.println();
    }
}