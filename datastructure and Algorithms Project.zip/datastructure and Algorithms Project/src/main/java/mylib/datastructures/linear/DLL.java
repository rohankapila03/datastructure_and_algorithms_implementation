package linear;
import nodes.*;

public class DLL{
    protected DNode head;
    protected DNode tail;
    protected int listSize;

    public DLL() {
        super();
        head = null;
        tail = null;
    }

    public DLL(DNode head) {
        this.head = head;
        this.tail = head;
        listSize = 1;
    }

    public void insertHead(DNode node) {
        DNode dNode = (DNode) node;
        dNode.next = head;
        if (head != null) {
            head.prev = dNode;
        }
        
        head = dNode;
        if (tail == null) {
            tail = dNode;
        }
        
        listSize++;
    }

    public void insertTail(DNode node) {
        DNode dNode = (DNode) node;
        if (head == null) {
            head = dNode;
            tail = dNode;
        } else {
            tail.next = dNode;
            dNode.prev = tail;
            tail = dNode;
        }
        listSize++;
    }

    public void insert(DNode node, int position) {
        if (position < 0 || position > listSize) {
            throw new IllegalArgumentException("Invalid position");
        }
        DNode dNode = (DNode) node;
        if (position == 0) {
            insertHead(dNode);
        } else if (position == listSize) {
            insertTail(dNode);
        } else {
            DNode current = head;
            for (int i = 1; i < position; i++) {
                current = current.next;
            }
            dNode.next = current.next;
            dNode.prev = current;
            current.next.prev = dNode;
            current.next = dNode;
            listSize++;
        }
    }

    private DNode getLastNode(DNode listHead) {
        if (listHead == null) {
            return null;
        }
        DNode current = listHead;
        while (current.next != null) {
            current = current.next;
        }
        return current;
    }
    
    public void sort() {
        if (head == null || head.next == null) {
            return;
        }

        DNode sortedList = null;
        DNode current = head;
        while (current != null) {
            DNode nextNode = current.next;
            sortedList = insertIntoSortedList(sortedList, current);
            current = nextNode;
        }
        head = sortedList;
        tail = getLastNode(sortedList);
    }

    public void sortedInsert(DNode node) {
        if (!isSorted()) {
            sort();
        }

        if (head == null || head.data >= node.data) {
            insertHead(node);
        } 
        else {
            DNode current = head;
            while (current.next != null && current.next.data < node.data) {
                current = current.next;
            }
            node.next = current.next;
            node.prev = current;
            if (current.next != null) {
                current.next.prev = node;
            } 
            else {
                tail = node;
            }
            current.next = node;
            listSize++;
        }
    }

    public DNode search(int data) {
        DNode current = head;
        while (current != null) {
            if (current.data == data) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    public void delete(int data) {
        if (head == null) {
            return;
        }
        if (head.data == data) {
            deleteHead();
            return;
        }
        DNode current = head;
        while (current.next != null && current.next.data != data) {
            current = current.next;
        }
        if (current.next != null) {
            if (current.next == tail) {
                deleteTail();
            } 
            else {
                current.next.next.prev = current;
                current.next = current.next.next;
                listSize--;
            }
        }
    }

    public void deleteHead() {
        if (head != null) {
            head = head.next;
            if (head != null) {
                head.prev = null;
            } 
            else {
                tail = null;
            }
            listSize--;
        }
    }

    public void deleteTail() {
        if (tail != null) {
            tail = tail.prev;
            if (tail != null) {
                tail.next = null;
            } 
            else {
                head = null;
            }
            listSize--;
        }
    }

    public void clear() {
        head = null;
        tail = null;
        listSize = 0;
    }

    public boolean isSorted() {
        if (head == null || head.next == null) {
            return true;
        }
        DNode current = head;
        while (current.next != null) {
            if (current.data > current.next.data) {
                return false;
            }
            current = current.next;
        }
        
        return true;
    }

    private DNode insertIntoSortedList(DNode sortedList, DNode node) {
        if (sortedList == null || sortedList.data >= node.data) {
            node.next = sortedList;
            if (sortedList != null) {
                sortedList.prev = node;
            }
            return node;
        } 
        
        else {
            DNode current = sortedList;
            while (current.next != null && current.next.data < node.data) {
                current = current.next;
            }
            
            node.next = current.next;
            node.prev = current;
            if (current.next != null) {
                current.next.prev = node;
            }
            current.next = node;
            return sortedList;
        }
    }

    public void print() {
        System.out.println("Length: " + listSize);
        System.out.println("Sorted?: " + (isSorted() ? "Yes" : "No"));

        System.out.print("Contents: ");
        DNode current = head;
        while (current != null) {
            System.out.print(current.data + (current.next != null ? " <-> " : ""));
            current = current.next;
        }
        System.out.println();
    }

}
