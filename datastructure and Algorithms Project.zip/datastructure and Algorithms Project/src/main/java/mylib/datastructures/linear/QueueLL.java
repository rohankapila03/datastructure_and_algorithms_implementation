package linear;
import nodes.DNode;
public class QueueLL extends SLL{
    
    public void enqueue(int data) {
        DNode newNode = new DNode(data);
        super.insertTail(newNode);
    }

    public int dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("The queue is empty");
        }
        int data = super.head.data;
        super.deleteHead();
        return data;
    }

    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("The queue is empty");
        }
        return super.head.data;
    }

    public boolean isEmpty() {
        return super.listSize == 0;
    }

    public int listSize() {
        return super.listSize;
    }

    public void print() {
        super.print();
    }

    @Override
    public void insertHead(DNode node) {}

    @Override
    public void insert(DNode node, int position) {}

    @Override
    public void sortedInsert(DNode node) {}

    @Override
    public void delete(int data) {}

    @Override
    public void sort() {}


}
